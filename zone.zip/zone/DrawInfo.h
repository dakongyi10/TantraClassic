#ifndef __ZONESRV_DRAWINFO_H__
#define __ZONESRV_DRAWINFO_H__

#include <windows.h>

extern int g_nCurrentTextY;

void DrawInformations( HDC hDC );

#endif //__ZONESRV_DRAWINFO_H__