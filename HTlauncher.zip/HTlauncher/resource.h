//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDR_MAIN_ACCEL                  101
#define IDS_INTRO_MSG_INPUT_IDPASSWORD  101
#define IDC_CURSOR1                     105
#define IDI_ICON1                       123
#define IDS_STRING124                   124
#define IDS_HELP_TITLE                  500
#define IDS_HELP_STRING1                501
#define IDS_HELP_STRING2                502
#define IDS_HELP_STRING3                503
#define IDS_HELP_STRING4                504
#define IDS_NOTIFY_MSG_TEMP             1000
#define IDS_CHATTING_MSG_TOO_LONG_NAMEVALUE 1122
#define IDS_CHATTING_MSG_TOO_LONG_MESSAGEVALUE 1123
#define IDS_CHATTING_MSG_FAILED_SEND    1127
#define IDS_CHATTING_MSG_FAILED_SEND_WHISPER 1128
#define IDS_CHATTING_MSG_FAILED_SEND_SHOUT 1129
#define IDS_CHATTING_MSG_FAILED_SEND_PARTY 1130
#define IDS_CHATTING_MSG_FAILED_SEND_GUILD 1131
#define IDS_CHATTING_MSG_CANNOT_SEND_MYSELF 1132
#define IDS_CHATTING_MSG_NO_NAME        1133
#define IDS_CHATTING_MSG_NO_MESSAGE     1134
#define IDM_TOGGLESCREEN                40001
#define IDM_EXITAPP                     40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        124
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
