#ifndef __DRAWINFO_H__
#define ___DRAWINFO_H__

#include <windows.h>

extern int g_nCurrentTextY;

void DrawInformations( HDC hDC );

#endif //__DRAWINFO_H__