


//BOOL InitApplication(HANDLE);
//BOOL InitInstance(HANDLE, int);
//LONG APIENTRY MainWndProc(HWND, UINT, UINT, LONG);


